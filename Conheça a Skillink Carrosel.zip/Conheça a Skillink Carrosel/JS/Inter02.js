const buttonMenu = document.querySelector('.button-menu');
const headerRight = document.querySelector('.header-right');

buttonMenu.addEventListener('click', () => {
  headerRight.classList.toggle('hidden');
});

// SCRIPT PAR AO SLIDE FUNCIONAR ABAIXO
$(document).ready(function(){
  $('.slick-carousel').slick({
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    dots: true,
    arrows: true,
  });
});